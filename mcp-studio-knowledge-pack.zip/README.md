# mcp-studio Drop-in

One zip. Two halves: a for-humans primer and a for-ai searchable knowledge base.

## What's inside

```
mcp-studio-dropin/
  for-humans/   — read first
    mcp-studio-primer.md         — top-down orientation: what it is, why, how it works
  for-ai/       — the searchable knowledge pack (wire this into your agent)
    mcp-studio-kb.rvf            — single 384-dim bge-small vector DB (the "brain")
    mcp-studio-kb.passages.jsonl — full passage text (347 passages; search returns TEXT, not {id,distance})
    mcp-studio-kb.ids.json       — id → passage index
    mcp-studio-symbols.json      — exact public API: every symbol + signature + doc + location
    mcp-studio-dep-graph.json    — component dependency graph (what depends on what)
    mcp-studio-entrypoints.json  — build/test/run/install commands + binaries
    ask-kb.mjs · kb-mcp-server.mjs · kb.config.mjs · resolve-deps.mjs · package.json
  README.md     — this file
  manifest.json — build metadata
```

## Studio (NotebookLM)
This is a **studio-less** build (INV-03): the searchable AI pack ships now; NotebookLM audio/report
media follow up later if produced. Nothing here depends on them.

## Three steps to wire the AI half in
```bash
# 1 — unzip + install (two deps, Node 18+)
unzip mcp-studio-knowledge-pack.zip && cd mcp-studio-dropin/for-ai && npm install

# 2 — ask the brain a question straight away
node ask-kb.mjs mcp-studio "what does mcp-studio actually do"

# 3 — point your AI host at it with a .mcp.json in your project root:
#   { "mcpServers": { "mcp-studio-kb": { "command": "node", "args": ["for-ai/kb-mcp-server.mjs"] } } }
```

Built with the Repo-Primer recipe (ADR-0001 / ADR-0005). Embedder: Xenova/bge-small-en-v1.5.
